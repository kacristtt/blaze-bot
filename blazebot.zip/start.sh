#!/bin/bash
python3 -m playwright install
python3 main.py
